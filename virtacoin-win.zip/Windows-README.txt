Relase Notes for VirtaCoin Windows Wallet

  To run your VirtaCoin wallet, just double-click on virtacoin-qt.exe.

  For advanced users who like to use the command line, we have included virtacoind.exe and virtacoin-cli.exe